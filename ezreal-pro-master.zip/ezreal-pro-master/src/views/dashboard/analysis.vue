<template>
  <div>我是analysis</div>
</template>

<script>
export default {
  name: 'home'
}
</script>

<style>
</style>
