<template>
  <div>
    我是search
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'search'
}
</script>

<style>
</style>
