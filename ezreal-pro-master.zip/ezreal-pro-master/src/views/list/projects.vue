<template>
  <div>
    我是projects
  </div>
</template>

<script>
export default {
  name: 'projects'
}
</script>

<style>
</style>
