<template>
  <div>
    我是articles
  </div>
</template>

<script>
export default {
  name: 'articles'
}
</script>

<style>
</style>
