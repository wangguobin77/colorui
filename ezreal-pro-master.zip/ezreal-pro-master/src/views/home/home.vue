<template>
  <div>
    我是home
    <!-- <a-menu
      mode="inline"
      theme="dark"
      :openKeys="['sub2', 'sub3']"
      :selectedKeys="['sub2', 'sub3', '8']"
      style="width: 256px"
    >
      <a-sub-menu key="sub2">
        <span slot="title"><a-icon type="appstore" /><span>Navigation Two</span></span>
        <a-menu-item key="5">Option 5</a-menu-item>
        <a-menu-item key="6">Option 6</a-menu-item>
        <a-sub-menu key="sub3" title="Submenu">
          <a-menu-item key="7">Option 7</a-menu-item>
          <a-menu-item key="8">Option 8</a-menu-item>
        </a-sub-menu>
      </a-sub-menu>
    </a-menu> -->
  </div>
</template>

<script>
export default {
  name: 'home'
}
</script>

<style>
</style>
