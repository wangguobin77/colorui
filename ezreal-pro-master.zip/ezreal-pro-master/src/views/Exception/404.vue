<template>
  <div>
    我是404页
  </div>
</template>

<script>
export default {
}
</script>

<style>
</style>
