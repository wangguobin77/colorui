<template>
  <div>
    无权限页
  </div>
</template>

<script>
export default {
}
</script>

<style>
</style>