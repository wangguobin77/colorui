<template>
  <div>
    我是500
  </div>
</template>

<script>
export default {
}
</script>

<style>
</style>