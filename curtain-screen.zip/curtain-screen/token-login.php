<?php
// login with token
if (!$token = $_GET['token'] ?? null) {
    echo "TOKEN NOT FOUND!!";
    exit;
}
if (!isset($_GET['user_info'])) {
    echo "USER INFO NOT FOUND!!";
    exit;
}
$user = base64_decode($_GET['user_info']);
?>

<script>
    localStorage.setItem('token', "<?= $token?>");
    localStorage.setItem('user',  '<?= $user ?>');
    window.location.href = "/index.html";
</script>