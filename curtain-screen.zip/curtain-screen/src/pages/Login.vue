<!-- @format -->

<template>
    <div class="login transparent">
        <a-card title="随手e裁窗帘车间MES" :bordered="false" style="width: 60%;margin: auto;">
            <a-form-model ref="ruleForm" :model="form" :rules="rules" v-bind="layout">
                <a-form-model-item has-feedback label="账号" prop="mobile">
                    <a-input v-model="form.mobile" type="text" autocomplete="off" placeholder="请输入账号" />
                </a-form-model-item>
                <a-form-model-item has-feedback label="密码" prop="password">
                    <a-input v-model="form.password" type="password" autocomplete="off" placeholder="请输入密码" />
                </a-form-model-item>
                <a-form-model-item :wrapper-col="{ span: 20, offset: 4 }" style="text-align:right">
                    <a-checkbox v-model="form.is_remember">
                        记住密码
                    </a-checkbox>
                </a-form-model-item>
                <a-form-model-item :wrapper-col="{ span: 16, offset: 4 }">
                    <a-button type="primary" @click="submitForm('ruleForm')">
                        登录
                    </a-button>
                    <a-button style="margin-left: 10px" @click="resetForm('ruleForm')">
                        重置
                    </a-button>
                </a-form-model-item>
            </a-form-model>
        </a-card>
    </div>
</template>

<script>
export default {
    name: 'Login',
    data() {
        return {
            form: {
                mobile: '',
                password: '',
                is_remember: true
            },
            rules: {
                mobile: [{ required: true, message: '请输入账号', trigger: 'change' }],
                password: [{ required: true, message: '请输入密码', trigger: 'change' }]
            },
            layout: {
                labelCol: { span: 4 },
                wrapperCol: { span: 20 }
            }
        }
    },
    mounted() {
        this.form = Object.assign(this.form, this.$store.getters.user_form)
    },
    methods: {
        submitForm() {
            this.$refs.ruleForm.validate(valid => {
                if (valid) {
                    this.$store.dispatch('Login', this.form)
                }
            })
        },
        resetForm() {
            this.$refs.ruleForm.resetFields()
        }
    }
}
</script>
<style lang="scss">
.login {
    padding: 30px;
    width: 100%;
    height: 100vh;
    margin: auto;
    padding-top: 10rem;
    .ant-card {
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0px 2px 6px 0px rgba(49, 197, 254, 1);
    }
    .ant-card-head-title {
        font-size: 2rem;
    }
    * {
        color: #31c5fe !important;
    }
}
</style>
