<!-- @format -->

<template>
    <a-row class="index-box" :gutter="[16, 16]" type="flex" justify="space-around">
        <a-col :span="4" />
        <a-col :span="8">
            <a href="#" style="display:block;">
                <a-card @click="changeScreen('/counting')">
                    <div>计件大屏</div>
                </a-card>
            </a>
        </a-col>
        <a-col :span="8">
            <a href="#" style="display:block;">
                <a-card @click="changeScreen('/machining')">
                    <div>加急&发货</div>
                </a-card>
            </a>
        </a-col>
        <a-col :span="4" />
        <a-col :span="4" />
        <a-col :span="8">
            <a href="#" style="display:block;">
                <a-card @click="changeScreen('/stock')">
                    <div>缺货&预警</div>
                </a-card>
            </a>
        </a-col>
        <a-col :span="8">
            <a href="#" style="display:block;">
                <a-card @click="changeScreen('/procedure')">
                    <div>工序&进度</div>
                </a-card>
            </a>
        </a-col>
        <a-col :span="4" />
    </a-row>
</template>
<script>
export default {
    name: 'Index',
    data() {
        return {}
    },
    mounted() {},
    methods: {
        changeScreen: function(path) {
            this.$router.push(path)
        }
    }
}
</script>
<style lang="scss">
.index-box {
    padding-top: 20%;
    .ant-card {
        color: rgba(16, 16, 16, 0.01);
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0px 2px 6px 0px rgba(49, 197, 254, 1);
    }
    .ant-card-body {
        color: #31c5fe;
        font-size: 2rem;
    }
}
</style>
