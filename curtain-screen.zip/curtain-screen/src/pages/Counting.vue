<!-- @format -->

<template>
    <a-row class="counting-box" justify="space-around" align="middle">
        <a-list :grid="{ gutter: 10, column: 6 }" :data-source="list">
            <a-list-item slot="renderItem" slot-scope="item" class="card">
                <a-card :bordered="bordered">
                    <div class="card-title">
                        <!-- <a-icon class="card-title-icon" type="user" />  -->
                        {{ item.name.substr(0, 3) }}<span v-if="item.default_process_step" class="card-title-right">-{{ item.default_process_step_label.substr(0, 5) }}</span>
                    </div>
                    <div class="card-count">
                        {{ item.today_quantity_total }}套<br /><span v-if="!item.enable_shoot_mode">{{ item.today_length_total }}米</span>
                    </div>
                </a-card>
            </a-list-item>
        </a-list>
    </a-row>
</template>
<script>
export default {
    name: 'Counting',
    data() {
        return {
            interval: false,
            bordered: false,
            loading: false,
            page: 1,
            total: 0,
            list: []
        }
    },
    beforeDestroy: function() {
        this.interval && clearInterval(this.interval)
    },
    mounted() {
        let _this = this
        this.getList()
        this.interval = setInterval(function() {
            !_this.loading && _this.getList()
        }, 60000)
    },
    methods: {
        getList: function() {
            this.loading = true
            this.$http.get('/screen/shops/workload', { page: this.page }).then(res => {
                // this.page = res.page
                // this.total = res.total ? res.total : 0
                this.list = res
                // if (!res.has_more) {
                //     this.page = 1
                //     this.has_more = 1
                // }
                this.loading = false
            })
        }
    }
}
</script>
<style lang="scss">
.counting-box {
    .ant-card {
        color: rgba(16, 16, 16, 0.01);
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0px 2px 6px 0px rgba(49, 197, 254, 1);
    }
    .ant-card-body {
        text-align: left;
        padding: 0.3rem;
        color: #31c5fe;
    }
    .card-title {
        text-align: left;
        font-size: 1.3rem;
        .card-title-right {
            font-size: 0.9rem;
        }
    }
    .card-title-icon {
        color: #ffffff;
    }
    .card-count {
        text-align: center;
        font-size: 1.2rem;
    }
}
</style>
