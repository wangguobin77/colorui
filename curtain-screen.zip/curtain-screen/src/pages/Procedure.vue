<!-- @format -->

<template>
    <a-row class="machining-box" :gutter="[4, 4]">
        <a-col :span="12">
            <div class="title">流水线（{{ procedure.total }}）</div>
            <a-table :columns="procedure.columns" :row-key="record => record.id" :pagination="false" :data-source="procedure_data" :loading="procedure.loading">
                <template slot="label" slot-scope="record"> {{ record.label ? record.label.substr(0, 6) : '' }} </template>
                <template slot="wait_count" slot-scope="record"> {{ record.wait_count ? record.wait_count : 0 }} </template>
                <template slot="min_time" slot-scope="record"> {{ record.min_time ? record.min_time.substr(5, 5) : '-' }} </template>
            </a-table>
        </a-col>
        <a-col :span="12">
            <div class="title">订单进度（{{ OrderProgress.total }}）</div>
            <a-table :columns="OrderProgress.columns" :row-key="record => record.id" :pagination="false" :data-source="OrderProgress_data" :loading="OrderProgress.loading">
                <template slot="urgent" slot-scope="record">
                    <a-icon v-if="record.urgent && record.urgent == 1" type="flag" theme="filled" :style="{ color: 'red' }" />
                </template>
                <template slot="order_no" slot-scope="record"> {{ record.order_no ? record.order_no.substr(-5) : '' }} </template>
                <template slot="client_label" slot-scope="record"> {{ record.client_label ? record.client_label.substr(0, 5) : '' }} </template>
                <template slot="group_total" slot-scope="record"> {{ record.type == 'batch_order' ? record.group_total : 1 }} </template>
                <template slot="created_at" slot-scope="record"> {{ record.created_at ? record.created_at.substr(5, 5) : '' }} </template>
                <template slot="delivery_date" slot-scope="record"> {{ record.delivery_date ? record.delivery_date.substr(5, 5) : '' }} </template>
                <template slot="flag" slot-scope="flag"> {{ flag.status_label }} </template>
            </a-table>
        </a-col>
    </a-row>
</template>
<script>
export default {
    name: 'Procedure',
    data() {
        return {
            limit: 18,
            OrderProgress_data: [],
            OrderProgress: {
                loading: false,
                interval: false,
                page: 1,
                current_page: 1,
                total: 0,
                columns: [
                    {
                        key: 'urgent',
                        width: '5%',
                        scopedSlots: { customRender: 'urgent' }
                    },
                    {
                        title: '序号',
                        key: 'id',
                        width: '8%',
                        customRender: (text, record, index) => `${(this.OrderProgress.current_page - 1) * this.limit + index + 1}`
                    },
                    {
                        title: '编号',
                        key: 'order_no',
                        width: '12%',
                        scopedSlots: { customRender: 'order_no' }
                    },
                    {
                        title: '客户',
                        key: 'client_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'client_label' }
                    },
                    {
                        title: '套数',
                        key: 'group_total',
                        width: '10%',
                        scopedSlots: { customRender: 'group_total' }
                    },
                    {
                        title: '创建',
                        key: 'created_at',
                        width: '15%',
                        scopedSlots: { customRender: 'created_at' }
                    },
                    {
                        title: '交付',
                        key: 'delivery_date',
                        width: '15%',
                        scopedSlots: { customRender: 'delivery_date' }
                    },
                    {
                        key: 'flag',
                        title: '进度',
                        ellipsis: true,
                        width: '15%',
                        scopedSlots: { customRender: 'flag' }
                    }
                ]
            },
            procedure_data: [],
            procedure: {
                loading: false,
                interval: false,
                page: 1,
                current_page: 1,
                total: 0,
                columns: [
                    {
                        title: '工序',
                        key: 'label',
                        width: '25%',
                        scopedSlots: { customRender: 'label' }
                    },
                    {
                        title: '最早时间',
                        key: 'min_time',
                        width: '25%',
                        scopedSlots: { customRender: 'min_time' }
                    },
                    {
                        title: '排队数量',
                        key: 'wait_count',
                        ellipsis: true,
                        scopedSlots: { customRender: 'wait_count' }
                    },
                    {
                        title: '今日套数',
                        width: '15%',
                        dataIndex: 'today_quantity_total'
                    },
                    {
                        title: '今日米数',
                        width: '15%',
                        ellipsis: true,
                        dataIndex: 'today_length_total'
                    }
                ]
            }
        }
    },
    beforeDestroy: function() {
        this.OrderProgress.interval && clearInterval(this.OrderProgress.interval)
        this.procedure.interval && clearInterval(this.procedure.interval)
    },
    mounted() {
        let _this = this
        this.getOrderProgressList()
        this.OrderProgress.interval = setInterval(function() {
            !_this.OrderProgress.loading && _this.getOrderProgressList()
        }, 30000)
        this.getProcedureList()
        this.procedure.interval = setInterval(function() {
            !_this.procedure.loading && _this.getProcedureList()
        }, 30000)
    },
    methods: {
        getOrderProgressList: function() {
            this.loading = true
            this.$http.get('/screen/orders/progress?type=order_progress&limit=' + this.limit + '&page=' + this.OrderProgress.page, { page: this.OrderProgress.page }).then(res => {
                if (!res || res.total <= 0) {
                    this.OrderProgress.loading = false
                    return
                }
                // if (res.screen_order_fields) {
                //     this.OrderProgress.columns = this.OrderProgress.columns.filter(item => !['design_label', 'install_location_label', 'delivery_date'].includes(item.key) || res.screen_order_fields.includes(item.key))
                // }
                this.OrderProgress.page = res.page
                this.OrderProgress.current_page = res.page - 1
                this.OrderProgress.total = res.total ? res.total : 0
                this.OrderProgress_data = res.data
                if (!res.has_more) {
                    this.OrderProgress.page = 1
                    this.OrderProgress.has_more = 1
                }
                this.OrderProgress.loading = false
            })
        },
        getProcedureList: function() {
            this.loading = true
            this.$http.get('/screen/orders/procedure?limit=' + this.limit + '&page=' + this.procedure.page, { page: this.procedure.page }).then(res => {
                if (!res.enable_shoot_mode) {
                    this.procedure = {
                        loading: false,
                        interval: false,
                        page: 1,
                        current_page: 1,
                        total: 0,
                        columns: [
                            {
                                title: '工序',
                                key: 'label',
                                width: '25%',
                                scopedSlots: { customRender: 'label' }
                            },
                            {
                                title: '最早时间',
                                key: 'min_time',
                                width: '25%',
                                scopedSlots: { customRender: 'min_time' }
                            },
                            {
                                title: '排队数量',
                                key: 'wait_count',
                                ellipsis: true,
                                scopedSlots: { customRender: 'wait_count' }
                            },
                            {
                                title: '今日套数',
                                width: '15%',
                                dataIndex: 'today_quantity_total'
                            },
                            {
                                title: '今日米数',
                                width: '15%',
                                ellipsis: true,
                                dataIndex: 'today_length_total'
                            }
                        ]
                    }
                } else {
                    this.procedure = {
                        loading: false,
                        interval: false,
                        page: 1,
                        current_page: 1,
                        total: 0,
                        columns: [
                            {
                                title: '工序',
                                key: 'label',
                                width: '25%',
                                scopedSlots: { customRender: 'label' }
                            },
                            {
                                title: '最早时间',
                                key: 'min_time',
                                width: '25%',
                                scopedSlots: { customRender: 'min_time' }
                            },
                            {
                                title: '排队数量',
                                key: 'wait_count',
                                ellipsis: true,
                                scopedSlots: { customRender: 'wait_count' }
                            },
                            {
                                title: '今日套数',
                                width: '25%',
                                dataIndex: 'today_quantity_total'
                            }
                        ]
                    }
                }
                if (res && res.total > 0) {
                    this.procedure.page = res.page
                    this.procedure.current_page = res.page - 1
                    this.procedure.total = res.total ? res.total : 0
                    this.procedure_data = res.data
                    if (!res.has_more) {
                        this.procedure.page = 1
                        this.procedure.has_more = 1
                    }
                }
                this.procedure.loading = false
            })
        }
    }
}
</script>

<style lang="scss">
.title {
    font-size: 1.5rem;
}
.machining-box {
    .ant-table-thead > tr > th,
    .ant-table-tbody > tr > td {
        color: #31c5fe;
        background: rgba(255, 255, 255, 0.1);
        padding: 0.1rem 0.015%;
        text-align: center;
    }
    .ant-table-placeholder {
        background: rgba(0, 0, 0, 0);
        border: none;
        .ant-empty-imagem svg,
        * {
            fill: #31c5fe !important;
        }
    }
}
</style>
