<!-- @format -->

<template>
    <a-layout>
        <a-layout-header class="transparent header">{{ $store.getters.user.shop_name }}智慧工厂</a-layout-header>
        <a-layout-content class="main">
            <router-view> <template v-cloak></template> </router-view
        ></a-layout-content>
    </a-layout>
</template>

<script>
export default {
    name: 'Frame',
    data() {
        return {}
    }
}
</script>
<style>
.header {
    color: #31c5fe;
    font-size: 2.5rem;
    height: 3.5rem;
    line-height: 3.5rem;
}
.main {
    padding: 0 4px;
    height: calc(100vh - 3.5rem);
}
</style>
