<!-- @format -->

<template>
    <a-row class="machining-box" :gutter="[4, 4]">
        <a-col :span="12">
            <div class="title">缺货单（{{ stock.total }}）</div>
            <a-table :columns="stock.columns" :row-key="record => record.id" :pagination="false" :data-source="stock_data" :loading="stock.loading">
                <template slot="urgent" slot-scope="record">
                    <a-icon v-if="record.urgent && record.urgent == 1" type="flag" theme="filled" :style="{ color: 'red' }" />
                </template>
                <template slot="order_no" slot-scope="record"> {{ record.order_no ? record.order_no.substr(-5) : '' }} </template>
                <template slot="flag" slot-scope="flag"> {{ flag.status_label }} </template>
                <template slot="size" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.window_height && record.window_width ? record.window_width + 'x' + record.window_height : '-' }} </template>
                <template slot="style_label" slot-scope="record"> {{ record.style_label ? record.style_label.substr(0, 5) : '' }} </template>
                <template slot="client_label" slot-scope="record"> {{ record.client_label ? record.client_label.substr(0, 5) : '' }} </template>
                <template slot="delivery_date" slot-scope="record"> {{ record.delivery_date ? record.delivery_date.substr(5, 5) : '' }} </template>
                <template slot="install_location_label" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.install_location_label }} </template>
            </a-table>
        </a-col>
        <a-col :span="12">
            <div class="title">预警单（{{ warning.total }}）</div>
            <a-table :columns="warning.columns" :row-key="record => record.id" :pagination="false" :data-source="warning_data" :loading="warning.loading">
                <template slot="urgent" slot-scope="record">
                    <a-icon v-if="record.urgent && record.urgent == 1" type="flag" theme="filled" :style="{ color: 'red' }" />
                </template>
                <template slot="order_no" slot-scope="record"> {{ record.order_no ? record.order_no.substr(-5) : '' }} </template>
                <template slot="flag" slot-scope="flag"> {{ flag.status_label }} </template>
                <template slot="size" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.window_height && record.window_width ? record.window_width + 'x' + record.window_height : '-' }} </template>
                <template slot="style_label" slot-scope="record"> {{ record.style_label ? record.style_label.substr(0, 5) : '' }} </template>
                <template slot="client_label" slot-scope="record"> {{ record.client_label ? record.client_label.substr(0, 5) : '' }} </template>
                <template slot="delivery_date" slot-scope="record"> {{ record.delivery_date ? record.delivery_date.substr(5, 5) : '' }} </template>
                <template slot="install_location_label" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.install_location_label }} </template>
            </a-table>
        </a-col>
    </a-row>
</template>
<script>
export default {
    name: 'Machining',
    data() {
        return {
            limit: 18,
            warning_data: [],
            warning: {
                loading: false,
                interval: false,
                page: 1,
                current_page: 1,
                total: 0,
                columns: [
                    {
                        key: 'urgent',
                        width: '5%',
                        scopedSlots: { customRender: 'urgent' }
                    },
                    {
                        title: '序号',
                        key: 'id',
                        width: '7%',
                        customRender: (text, record, index) => `${(this.warning.current_page - 1) * this.limit + index + 1}`
                    },
                    {
                        title: '编号',
                        key: 'order_no',
                        width: '15%',
                        scopedSlots: { customRender: 'order_no' }
                    },
                    {
                        title: '客户',
                        key: 'client_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'client_label' }
                    },
                    {
                        title: '尺寸',
                        key: 'size',
                        width: '14%',
                        scopedSlots: { customRender: 'size' }
                    },
                    {
                        title: '风格',
                        key: 'style_label',
                        width: '15%',
                        dataIndex: 'style_label'
                    },
                    {
                        title: '款式',
                        key: 'design_label',
                        width: '15%',
                        dataIndex: 'design_label'
                    },
                    {
                        title: '交付',
                        key: 'delivery_date',
                        width: '15%',
                        scopedSlots: { customRender: 'delivery_date' }
                    },
                    {
                        title: '位置',
                        width: '15%',
                        key: 'install_location_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'install_location_label' }
                    },
                    {
                        key: 'flag',
                        title: '进度',
                        ellipsis: true,
                        width: '15%',
                        scopedSlots: { customRender: 'flag' }
                    }
                ]
            },
            stock_data: [],
            stock: {
                loading: false,
                interval: false,
                page: 1,
                current_page: 1,
                total: 0,
                columns: [
                    {
                        key: 'urgent',
                        width: '5%',
                        scopedSlots: { customRender: 'urgent' }
                    },
                    {
                        title: '序号',
                        key: 'id',
                        width: '7%',
                        customRender: (text, record, index) => `${(this.stock.current_page - 1) * this.limit + index + 1}`
                    },
                    {
                        title: '编号',
                        key: 'order_no',
                        width: '15%',
                        scopedSlots: { customRender: 'order_no' }
                    },
                    {
                        title: '客户',
                        key: 'client_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'client_label' }
                    },
                    {
                        title: '尺寸',
                        key: 'size',
                        width: '14%',
                        scopedSlots: { customRender: 'size' }
                    },
                    {
                        title: '风格',
                        key: 'style_label',
                        width: '15%',
                        dataIndex: 'style_label'
                    },
                    {
                        title: '款式',
                        key: 'design_label',
                        width: '15%',
                        dataIndex: 'design_label'
                    },
                    {
                        title: '交付',
                        key: 'delivery_date',
                        width: '15%',
                        scopedSlots: { customRender: 'delivery_date' }
                    },
                    {
                        title: '位置',
                        width: '15%',
                        key: 'install_location_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'install_location_label' }
                    },
                    {
                        key: 'flag',
                        title: '进度',
                        ellipsis: true,
                        width: '15%',
                        scopedSlots: { customRender: 'flag' }
                    }
                ]
            }
        }
    },
    beforeDestroy: function() {
        this.warning.interval && clearInterval(this.warning.interval)
        this.stock.interval && clearInterval(this.stock.interval)
    },
    mounted() {
        let _this = this
        this.getWarningList()
        this.warning.interval = setInterval(function() {
            !_this.warning.loading && _this.getWarningList()
        }, 30000)
        this.getStockList()
        this.stock.interval = setInterval(function() {
            !_this.stock.loading && _this.getStockList()
        }, 30000)
    },
    methods: {
        getWarningList: function() {
            this.loading = true
            this.$http.get('/screen/orders/progress?type=warning&day=1&limit=' + this.limit + '&page=' + this.warning.page, { page: this.warning.page }).then(res => {
                if (!res || res.total <= 0) {
                    this.warning.loading = false
                    return
                }
                if (res.screen_order_fields) {
                    this.warning.columns = this.warning.columns.filter(item => !['style_label', 'design_label', 'install_location_label', 'delivery_date'].includes(item.key) || res.screen_order_fields.includes(item.key))
                }

                this.warning.page = res.page
                this.warning.current_page = res.page - 1
                this.warning.total = res.total ? res.total : 0
                this.warning_data = res.data
                if (!res.has_more) {
                    this.warning.page = 1
                    this.warning.has_more = 1
                }
                this.warning.loading = false
            })
        },
        getStockList: function() {
            this.loading = true
            this.$http.get('/screen/orders/progress?type=outStock&limit=' + this.limit + '&page=' + this.stock.page, { page: this.stock.page }).then(res => {
                if (!res || res.total <= 0) {
                    this.stock.loading = false
                    return
                }
                if (res.screen_order_fields) {
                    this.stock.columns = this.stock.columns.filter(item => !['style_label', 'design_label', 'install_location_label', 'delivery_date'].includes(item.key) || res.screen_order_fields.includes(item.key))
                }
                this.stock.page = res.page
                this.stock.current_page = res.page - 1
                this.stock.total = res.total ? res.total : 0
                this.stock_data = res.data
                if (!res.has_more) {
                    this.stock.page = 1
                    this.stock.has_more = 1
                }

                this.stock.loading = false
            })
        }
    }
}
</script>

<style lang="scss">
.title {
    font-size: 1.5rem;
}
.machining-box {
    .ant-table-thead > tr > th,
    .ant-table-tbody > tr > td {
        color: #31c5fe;
        background: rgba(255, 255, 255, 0.1);
        padding: 0.1rem 0.015%;
        text-align: center;
    }
    .ant-table-placeholder {
        background: rgba(0, 0, 0, 0);
        border: none;
        .ant-empty-imagem svg,
        * {
            fill: #31c5fe !important;
        }
    }
}
</style>
