<!-- @format -->

<template>
    <a-row class="machining-box" :gutter="[4, 4]">
        <a-col :span="12">
            <div class="title">加急单（{{ anxious.total }}）</div>
            <a-table :columns="anxious.columns" :row-key="record => record.id" :pagination="false" :data-source="anxious_data" :loading="anxious.loading">
                <template slot="urgent" slot-scope="record">
                    <a-icon v-if="record.urgent && record.urgent == 1" type="flag" theme="filled" :style="{ color: 'red' }" />
                </template>
                <template slot="order_no" slot-scope="record"> {{ record.order_no ? record.order_no.substr(-5) : '' }} </template>
                <template slot="style_label" slot-scope="record"> {{ record.style_label ? record.style_label.substr(0, 5) : '' }} </template>
                <template slot="client_label" slot-scope="record"> {{ record.client_label ? record.client_label.substr(0, 5) : '' }} </template>
                <template slot="size" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.window_height && record.window_width ? record.window_width + 'x' + record.window_height : '-' }} </template>
                <template slot="delivery_date" slot-scope="record"> {{ record.delivery_date ? record.delivery_date.substr(5, 5) : '' }} </template>
                <template slot="flag" slot-scope="flag"> {{ flag.status_label }} </template>
                <template slot="install_location_label" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.install_location_label }} </template>
            </a-table>
        </a-col>
        <a-col :span="12">
            <div class="title">发货区（{{ finish.total }}）</div>
            <a-table :columns="finish.columns" :row-key="record => record.id" :pagination="false" :data-source="finish_data" :loading="finish.loading">
                <template slot="urgent" slot-scope="record">
                    <a-icon v-if="record.urgent && record.urgent == 1" type="flag" theme="filled" :style="{ color: 'red' }" />
                </template>
                <template slot="order_no" slot-scope="record"> {{ record.order_no ? record.order_no.substr(-5) : '' }} </template>
                <template slot="client_label" slot-scope="record"> {{ record.client_label ? record.client_label.substr(0, 5) : '' }} </template>
                <template slot="updated_at" slot-scope="record"> {{ record.updated_at ? record.updated_at.substr(5, 5) : '' }} </template>
                <template slot="install_location_label" slot-scope="record"> {{ record.shoot_mode ? record.style_label : record.install_location_label }} </template>
            </a-table>
        </a-col>
    </a-row>
</template>
<script>
export default {
    name: 'Machining',
    data() {
        return {
            limit: 18,
            anxious_data: [],
            anxious: {
                loading: false,
                interval: false,
                page: 1,
                current_page: 1,
                total: 0,
                columns: [
                    {
                        key: 'urgent',
                        width: '5%',
                        scopedSlots: { customRender: 'urgent' }
                    },
                    {
                        title: '序号',
                        key: 'id',
                        width: '7%',
                        customRender: (text, record, index) => `${(this.anxious.current_page - 1) * this.limit + index + 1}`
                    },
                    {
                        title: '编号',
                        key: 'order_no',
                        width: '15%',
                        scopedSlots: { customRender: 'order_no' }
                    },
                    {
                        title: '客户',
                        key: 'client_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'client_label' }
                    },
                    {
                        title: '尺寸',
                        key: 'size',
                        width: '14%',
                        scopedSlots: { customRender: 'size' }
                    },
                    {
                        title: '风格',
                        key: 'style_label',
                        width: '15%',
                        dataIndex: 'style_label'
                    },
                    {
                        title: '款式',
                        key: 'design_label',
                        width: '15%',
                        dataIndex: 'design_label'
                    },
                    {
                        title: '交付',
                        key: 'delivery_date',
                        width: '15%',
                        scopedSlots: { customRender: 'delivery_date' }
                    },
                    {
                        title: '位置',
                        width: '15%',
                        key: 'install_location_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'install_location_label' }
                    },
                    {
                        key: 'flag',
                        title: '进度',
                        ellipsis: true,
                        width: '15%',
                        scopedSlots: { customRender: 'flag' }
                    }
                ]
            },
            finish_data: [],
            finish: {
                loading: false,
                interval: false,
                page: 1,
                current_page: 1,
                total: 0,
                columns: [
                    {
                        key: 'urgent',
                        width: '5%',
                        scopedSlots: { customRender: 'urgent' }
                    },
                    {
                        title: '序号',
                        key: 'id',
                        width: '7%',
                        customRender: (text, record, index) => `${(this.finish.current_page - 1) * this.limit + index + 1}`
                    },
                    {
                        title: '编号',
                        key: 'order_no',
                        width: '15%',
                        scopedSlots: { customRender: 'order_no' }
                    },
                    {
                        title: '客户',
                        key: 'client_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'client_label' }
                    },
                    {
                        title: '套数',
                        width: '10%',
                        dataIndex: 'group_total'
                    },
                    {
                        title: '完成',
                        key: 'updated_at',
                        width: '15%',
                        scopedSlots: { customRender: 'updated_at' }
                    },
                    {
                        title: '位置',
                        width: '15%',
                        key: 'install_location_label',
                        ellipsis: true,
                        scopedSlots: { customRender: 'install_location_label' }
                    }
                ]
            }
        }
    },
    beforeDestroy: function() {
        this.anxious.interval && clearInterval(this.anxious.interval)
        this.finish.interval && clearInterval(this.finish.interval)
    },
    mounted() {
        let _this = this
        this.getAnxiousList()
        this.anxious.interval = setInterval(function() {
            !_this.anxious.loading && _this.getAnxiousList()
        }, 30000)
        this.getFinishList()
        this.finish.interval = setInterval(function() {
            !_this.finish.loading && _this.getFinishList()
        }, 30000)
    },
    methods: {
        getAnxiousList: function() {
            this.loading = true
            this.$http.get('/screen/orders/progress?type=urgent&limit=' + this.limit + '&page=' + this.anxious.page, { page: this.anxious.page }).then(res => {
                if (!res || res.total <= 0) {
                    this.anxious.loading = false
                    return
                }
                if (res.screen_order_fields) {
                    this.anxious.columns = this.anxious.columns.filter(item => !['style_label', 'design_label', 'install_location_label', 'delivery_date'].includes(item.key) || res.screen_order_fields.includes(item.key))
                }
                this.anxious.page = res.page
                this.anxious.current_page = res.page - 1
                this.anxious.total = res.total ? res.total : 0
                this.anxious_data = res.data
                if (!res.has_more) {
                    this.anxious.page = 1
                    this.anxious.has_more = 1
                }

                this.anxious.loading = false
            })
        },
        getFinishList: function() {
            this.loading = true
            this.$http.get('/screen/orders/progress?type=delivery&limit=' + this.limit + '&page=' + this.finish.page, { page: this.finish.page }).then(res => {
                if (!res || res.total <= 0) {
                    this.finish.loading = false
                    return
                }
                // if (res.screen_order_fields) {
                //     this.finish.columns = this.finish.columns.filter(item => !['style_label', 'design_label', 'install_location_label', 'delivery_date'].includes(item.key) || res.screen_order_fields.includes(item.key))
                // }
                this.finish.page = res.page
                this.finish.current_page = res.page - 1
                this.finish.total = res.total ? res.total : 0
                this.finish_data = res.data
                if (!res.has_more) {
                    this.finish.page = 1
                    this.finish.has_more = 1
                }

                this.finish.loading = false
            })
        }
    }
}
</script>

<style lang="scss">
.title {
    font-size: 1.5rem;
}
.machining-box {
    .ant-table-thead > tr > th,
    .ant-table-tbody > tr > td {
        color: #31c5fe;
        background: rgba(255, 255, 255, 0.1);
        padding: 0.1rem 0.015%;
        text-align: center;
    }
    .ant-table-placeholder {
        background: rgba(0, 0, 0, 0);
        border: none;
        .ant-empty-imagem svg,
        * {
            fill: #31c5fe !important;
        }
    }
}
</style>
