<!-- @format -->

<template>
    <div id="app" :style="{ backgroundImage: 'url(' + background + ')' }">
        <a-spin class="loading" size="large" tip="Loading..." :spinning="$store.getters.spin">
            <router-view></router-view>
        </a-spin>
    </div>
</template>

<script>
export default {
    name: 'App',
    data() {
        return {
            background: require('@/assets/background.png')
        }
    }
}
</script>

<style>
#app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    min-height: 100%;
    height: 100%;
    min-height: 100vh;
    height: 100vh;
    width: 100%;
    min-width: 100%;
    width: 100vw;
    min-width: 100vw;
    overflow-y: hidden;
    overflow: hidden;
    -moz-user-select: none; /*火狐*/
    -webkit-user-select: none; /*webkit浏览器*/
    -ms-user-select: none; /*IE10*/
    -khtml-user-select: none; /*早期浏览器*/
    -webkit-touch-callout: none;
    user-select: none;
    text-align: center;
    color: #31c5fe;
    background-repeat: no-repeat;
    background-size: 100% 100%;
}
body {
    padding: 0;
    margin: 0;
    overflow-y: hidden;
    overflow: hidden;
    -moz-user-select: none; /*火狐*/
    -webkit-user-select: none; /*webkit浏览器*/
    -ms-user-select: none; /*IE10*/
    -khtml-user-select: none; /*早期浏览器*/
    -webkit-touch-callout: none;
    user-select: none;
}
.spin-content {
    border: 1px solid #91d5ff;
    background-color: #e6f7ff;
    padding: 30px;
}
.ant-layout,
.transparent {
    background: rgba(0, 0, 0, 0);
}
[v-cloak] {
    display: none;
}
</style>
