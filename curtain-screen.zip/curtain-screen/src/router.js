/** @format */

import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/pages/Login'
import Frame from '@/pages/Frame'
import Index from '@/pages/Index'
import Machining from '@/pages/Machining'
import OutStock from '@/pages/OutStock'
import Procedure from '@/pages/Procedure'
import Counting from '@/pages/Counting'

Vue.use(Router)
export default new Router({
    routes: [
        {
            path: '/login',
            name: 'Login',
            component: Login,
            meta: {
                hidden: true,
                title: '登录'
            }
        },
        {
            path: '',
            component: Frame,
            name: '',
            meta: {
                hidden: false
            },
            children: [
                {
                    path: '/',
                    name: '首页',
                    component: Index
                },
                {
                    path: '/machining',
                    name: '加急&发货',
                    component: Machining
                },
                {
                    path: '/stock',
                    name: '缺货&预警',
                    component: OutStock
                },
                {
                    path: '/procedure',
                    name: '工序&进度',
                    component: Procedure
                },
                {
                    path: '/counting',
                    name: '计件大屏',
                    component: Counting
                }
            ]
        }
    ]
})
