/** @format */
'use strict'
import Vue from 'vue'
import App from './App'
import router from './router'
import axios from 'axios'
import Vuex from 'vuex'
import CryptoJS from 'crypto-js'

import { Button, Card, Col, Checkbox, FormModel, Icon, Input, Layout, List, Modal, notification, Row, Spin, Table } from 'ant-design-vue'

Vue.use(Vuex)
// 取消 Vue 所有的日志与警告
Vue.config.silent = false
Vue.config.productionTip = false
Vue.use(Button)
    .use(Card)
    .use(Col)
    .use(Checkbox)
    .use(FormModel)
    .use(Icon)
    .use(Input)
    .use(Layout)
    .use(List)
    .use(Modal)
    .use(notification)
    .use(Row)
    .use(Spin)
    .use(Table)
Vue.prototype.$info = Modal.info
Vue.prototype.$success = Modal.success
Vue.prototype.$error = Modal.error
Vue.prototype.$warning = Modal.warning
Vue.prototype.$confirm = Modal.confirm
Vue.prototype.$destroyAll = Modal.destroyAll
notification.config({
    placement: 'bottomRight',
    bottom: '50px',
    duration: 3
})
//测试环境
//正式环境
let timeout = 30000
axios.defaults.baseURL = process.env.VUE_APP_baseURL
axios.defaults.timeout = timeout
axios.interceptors.request.use(
    function(config) {
        if (store.getters.token) {
            config.headers['Authorization'] = 'Bearer ' + store.getters.token // 让每个请求携带自定义token 请根据实际情况自行修改
        }
        return config
    },
    function(error) {
        return Promise.reject(error)
    }
)

axios.interceptors.response.use(
    ({ data }) => {
        if (data.code === 999) {
            store.commit('SET_TOKEN', '')
            router.replace('/login')
        } else if (data.success !== true) {
            notification.error({
                message: '错误',
                description: data.message ? data.message : '系统错误...',
                onOk() {
                    if (data.code === 999) {
                        router.replace('/login')
                    } else if (data.err === 500) {
                        // 需要刷新的错误代码
                        router.replace('/login')
                    }
                }
            })
        }
        return data.data
    },
    error => {
        Vue.prototype.$loading = false
        if (error.code === 'ECONNABORTED') {
            notification.error({
                message: '错误',
                description: '请求超时，请检查网络连接或刷新重试...',
                onOk() {
                    // window.location.reload()
                }
            })
            return Promise.reject(error)
        }
        notification.error({
            message: error ? error : '系统错误',
            onOk() {
                // router.replace('/')
            }
        })
        return Promise.reject(error)
    }
)

Vue.prototype.$http = axios

// 状态管理
const store = new Vuex.Store({
    strict: true,
    state: {
        token: localStorage.getItem('token'),
        spin: false,
        user_form: localStorage.getItem('user_form'),
        user: localStorage.getItem('user')
    },
    getters: {
        token: state => (state.token ? state.token : ''),
        spin: state => !!state.spin,
        user_form: state => {
            let user_form = {
                mobile: '',
                password: '',
                is_remember: true
            }
            try {
                return Object.assign(user_form, state.user_form ? JSON.parse(CryptoJS.AES.decrypt(state.user_form, axios.defaults.baseURL).toString(CryptoJS.enc.Utf8)) : {})
            } catch ($e) {
                store.commit('SET_TOKEN', '')
                return user_form
            }
        },
        user: state => {
            try {
                let user = {
                    id: '',
                    shop_id: '',
                    client_id: '',
                    name: '',
                    email: '',
                    mobile: '',
                    type: '',
                    status: '',
                    process_steps: [],
                    from_user_id: '',
                    brand: '',
                    shop_name: '随手e裁',
                    perms: [],
                    accounts: []
                }
                return Object.assign(user, state.user ? JSON.parse(state.user) : {})
            } catch ($e) {
                console.log($e)
                notification.error({
                    message: '错误',
                    description: '获取用户信息失败...',
                    onOk() {
                        store.dispatch('clearLoginInfo')
                    }
                })
            }
        }
    },
    mutations: {
        SET_TOKEN: (state, token) => {
            state.token = token ? token : ''
            localStorage.setItem('token', token ? token : '')
        },
        SET_USER: (state, user) => {
            state.user = user ? JSON.stringify(user) : ''
            localStorage.setItem('user', user ? JSON.stringify(user) : '')
        },
        SET_USER_FORM: (state, user_form) => {
            let encrypt_user_form = CryptoJS.AES.encrypt(JSON.stringify(user_form), axios.defaults.baseURL).toString()
            state.user_form = encrypt_user_form ? encrypt_user_form : ''
            localStorage.setItem('user_form', encrypt_user_form ? encrypt_user_form : '')
        },
        SET_SPIN: (state, spin) => {
            state.spin = !!spin
        }
    },
    actions: {
        Login: ({ commit, dispatch }, userInfo) => {
            axios.post('/user/login', userInfo).then(res => {
                if (res) {
                    commit('SET_USER_FORM', userInfo.is_remember ? userInfo : {})
                    dispatch('LoginSuccess', res)
                }
            })
        },
        LoginSuccess({ commit }, res) {
            commit('SET_TOKEN', res.api_token)
            commit('SET_USER', res)
            router.replace('/')
        },
        async clearLoginInfo({ commit }) {
            commit('SET_TOKEN', '')
            commit('SET_USER', '')
            router.currentRoute.path.trim() !== '/login' && router.replace('/login').then()
        },
        Logout: ({ dispatch }) => {
            Modal.confirm({
                title: '您确定要退出登录？',
                onOk() {
                    dispatch('clearLoginInfo')
                    location.reload()
                },
                onCancel() {}
            })
        }
    }
})

router.beforeEach(async (to, from, next) => {
    document.title = to.name
    if (to.path === '/login') {
        store.commit('SET_TOKEN', '')
        from.path !== '/login' && next()
    } else if (!store.getters.token) {
        store.commit('SET_TOKEN', '')
        next({
            path: '/login'
        })
    } else {
        next()
    }
})
router.afterEach(() => {})
new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')
